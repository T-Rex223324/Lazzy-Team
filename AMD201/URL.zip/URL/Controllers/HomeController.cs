using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace URL.Controllers
{
    public class HomeController : Controller
    {
        private static Dictionary<string, string> urlDatabase = new();

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Shorten(string originalUrl)
        {
            if (string.IsNullOrEmpty(originalUrl))
            {
                ViewBag.Error = "Please enter a valid URL.";
                return View("Index");
            }

            // Generate a short unique key (6 characters)
            string shortCode = GenerateShortCode();
            urlDatabase[shortCode] = originalUrl;

            // Send the short URL to the view
            ViewBag.ShortUrl = $"{Request.Scheme}://{Request.Host}/go/{shortCode}";
            return View("Index");
        }

        [HttpGet("/go/{shortCode}")]
        public IActionResult RedirectToOriginal(string shortCode)
        {
            if (urlDatabase.TryGetValue(shortCode, out string originalUrl))
            {
                return Redirect(originalUrl);
            }

            return NotFound("Shortened URL not found.");
        }

        private string GenerateShortCode()
        {
            const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            StringBuilder result = new();
            Random random = new();

            for (int i = 0; i < 6; i++)
            {
                result.Append(chars[random.Next(chars.Length)]);
            }

            return result.ToString();
        }
    }
}
