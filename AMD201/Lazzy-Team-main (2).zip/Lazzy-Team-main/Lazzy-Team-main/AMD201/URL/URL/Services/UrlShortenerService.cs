﻿using System.Text;
using Microsoft.EntityFrameworkCore;
using URl.Data;
using URl.Models;

namespace URl.Services
{
    public class UrlShortenerService
    {
        private readonly ApplicationDbContext _context;
        private const string AllowedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        private const int CodeLength = 6;

        public UrlShortenerService(ApplicationDbContext context)
        {
            _context = context;
        }

        public string GenerateShortCode()
        {
            var random = new Random();
            var shortCode = new StringBuilder();

            for (int i = 0; i < CodeLength; i++)
            {
                shortCode.Append(AllowedChars[random.Next(AllowedChars.Length)]);
            }

            return shortCode.ToString();
        }

        public async Task<string> ShortenUrlAsync(string originalUrl)
        {
            string shortCode;
            do
            {
                shortCode = GenerateShortCode();
            } while (await _context.ShortUrls.AnyAsync(u => u.ShortCode == shortCode));

            var shortUrl = new ShortUrl 
            {
                OriginalUrl = originalUrl,
                ShortCode = shortCode
            };

            _context.ShortUrls.Add(shortUrl);
            await _context.SaveChangesAsync();
            return shortCode;
        }

        public async Task<string?> GetOriginalUrlAsync(string shortCode)
        {
            var shortUrl = await _context.ShortUrls.FirstOrDefaultAsync(u => u.ShortCode == shortCode);
            return shortUrl?.OriginalUrl;
        }
    }
}
