﻿using Microsoft.AspNetCore.Mvc;
using URl.Data;       
using URl.Services;   

namespace URl.Controllers  
{
    [ApiController]
    [Route("[controller]")]
    public class UrlShortenerController : ControllerBase
    {
        private readonly UrlShortenerService _urlShortenerService;

        public UrlShortenerController(ApplicationDbContext context)
        {
            _urlShortenerService = new UrlShortenerService(context);
        }

        [HttpPost("shorten")]
        public async Task<IActionResult> Shorten([FromBody] string originalUrl)
        {
            if (string.IsNullOrWhiteSpace(originalUrl))
                return BadRequest("Invalid URL");

            string shortCode = await _urlShortenerService.ShortenUrlAsync(originalUrl);
            string shortUrl = $"{Request.Scheme}://{Request.Host}/{shortCode}";

            return Ok(new { shortUrl });
        }

        [HttpGet("{shortCode}")]
        public async Task<IActionResult> RedirectUrl(string shortCode)
        {
            var originalUrl = await _urlShortenerService.GetOriginalUrlAsync(shortCode);
            if (originalUrl == null)
                return NotFound("URL not found");

            return Redirect(originalUrl);
        }
    }
}
