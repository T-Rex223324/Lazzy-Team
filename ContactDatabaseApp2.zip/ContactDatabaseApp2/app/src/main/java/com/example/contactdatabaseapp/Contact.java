package com.example.contactdatabaseapp; // UPDATED PACKAGE NAME

public class Contact {
    private String name;
    private String dob;
    private String email;

    public Contact(String name, String dob, String email) {
        this.name = name;
        this.dob = dob;
        this.email = email;
    }

    public String getName() { return name; }
    public String getDob() { return dob; }
    public String getEmail() { return email; }
}