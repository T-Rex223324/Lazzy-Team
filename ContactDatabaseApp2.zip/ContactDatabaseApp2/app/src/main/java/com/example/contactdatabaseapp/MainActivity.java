package com.example.contactdatabaseapp; // UPDATED PACKAGE NAME

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText name, dob, email;
    Button view, save;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.etName);
        dob = findViewById(R.id.etDob);
        email = findViewById(R.id.etEmail);
        view = findViewById(R.id.btnViewDetails);
        save = findViewById(R.id.btnSaveDetails);
        DB = new DBHelper(this);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String dobTXT = dob.getText().toString();
                String emailTXT = email.getText().toString();

                Boolean checkinsertdata = DB.insertUserData(nameTXT, dobTXT, emailTXT);
                if(checkinsertdata) {
                    Toast.makeText(MainActivity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                    name.setText("");
                    dob.setText("");
                    email.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ContactListActivity.class);
                startActivity(intent);
            }
        });
    }
}