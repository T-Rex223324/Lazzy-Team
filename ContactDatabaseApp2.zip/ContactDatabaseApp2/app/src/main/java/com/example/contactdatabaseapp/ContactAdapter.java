package com.example.contactdatabaseapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.MyViewHolder> {

    private ArrayList<Contact> contactList;

    public ContactAdapter(ArrayList<Contact> contactList) {
        this.contactList = contactList;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nameTxt, dobTxt, emailTxt;

        public MyViewHolder(final View view) {
            super(view);
            nameTxt = view.findViewById(R.id.tvName);
            dobTxt = view.findViewById(R.id.tvDob);
            emailTxt = view.findViewById(R.id.tvEmail);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_contact, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Contact contact = contactList.get(position);
        holder.nameTxt.setText(contact.getName());
        holder.dobTxt.setText(contact.getDob());
        holder.emailTxt.setText(contact.getEmail());
    }

    @Override
    public int getItemCount() {
        return contactList.size();
    }
}