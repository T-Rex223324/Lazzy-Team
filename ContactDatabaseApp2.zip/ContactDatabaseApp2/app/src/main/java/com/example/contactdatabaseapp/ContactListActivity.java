package com.example.contactdatabaseapp; // This MUST match your folder structure

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;
import java.util.ArrayList;

public class ContactListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Contact> contactList;
    DBHelper DB;
    ContactAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);

        DB = new DBHelper(this); // This line was failing because it couldn't find DBHelper
        contactList = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView);

        adapter = new ContactAdapter(contactList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        displayData();
    }

    private void displayData() {
        Cursor cursor = DB.getData();
        if(cursor.getCount() == 0) {
            Toast.makeText(ContactListActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }

        while(cursor.moveToNext()) {
            contactList.add(new Contact(
                    cursor.getString(0),
                    cursor.getString(1),
                    cursor.getString(2)
            ));
        }
        adapter.notifyDataSetChanged();
    }
}