const express = require('express');
const app = express(); // ✅ Declare app early

const cors = require('cors');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

global.Vocab = require('./api/models/vocabModels'); // ✅ This assumes your model registers with mongoose.model()
const routes = require('./api/routes/vocabRoutes');

// Middleware
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.json()); // ✅ Now it's safe to use

// MongoDB connection
mongoose.set('strictQuery', true);
mongoose.connect('mongodb://localhost/vocab-builder');

// Register routes
routes(app);

// Start server
const port = process.env.PORT || 8080; //3000;
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});

// 404 Handler
app.use((req, res) => {
  res.status(404).send({ url: `${req.originalUrl} not found` });
});
